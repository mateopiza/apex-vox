/**
 * Apex Box — Grabador en pestaña fija (recorder/recorder.js)
 * ----------------------------------------------------------
 * 1. El usuario elige tipo de reunión, título, tipo de grabación y modelo.
 * 2. Graba en bloques de 3 min (cada bloque se sube y se libera de la RAM).
 * 3. Al detener, finaliza la sesión y entrega un enlace con notas, resumen y acta.
 * El icono de la extensión muestra REC + tiempo mientras se graba.
 */

"use strict";

// Idioma de la interfaz: el del navegador (español o inglés)
const UI_LANG = String((chrome.i18n && chrome.i18n.getUILanguage()) || navigator.language || "es")
  .toLowerCase().startsWith("es") ? "es" : "en";
const L = (es, en) => (UI_LANG === "en" ? en : es);
const STATIC_EN = {
  "Apex Box · Grabador": "Apex Box · Recorder",
  "NO REC": "NOT REC",
  "Tipo de reunión": "Meeting type",
  "Ejecutiva": "Executive",
  "Consejo / Junta directiva": "Board of directors",
  "Comité": "Committee",
  "Asamblea": "Assembly",
  "Seguimiento": "Follow-up",
  "Título": "Title",
  "Ej. Comité semanal de ventas": "E.g. Weekly sales committee",
  "Tipo de grabación": "Recording type",
  "Presencial": "In person",
  "Virtual": "Virtual",
  "Modelo": "Model",
  "Mc-Lewis · Híbrido": "Mc-Lewis · Hybrid",
  "Mc-Ayrton · Máxima precisión": "Mc-Ayrton · Highest accuracy",
  "Mc-Norris · Huella vocal": "Mc-Norris · Voiceprint",
  "Mc-Piastri · Ultra rápido": "Mc-Piastri · Ultra fast",
  "Sin grabar": "Not recording",
  "● Grabar": "● Record",
  "Iniciar sesión en Apex Vox": "Sign in to Apex Vox",
  "Comprobando sesión…": "Checking session…",
  "Bloques enviados": "Blocks sent",
  "Segmentos": "Sentences",
  "Hablantes": "Speakers",
  "Pendientes": "Pending",
  "Reunión lista": "Meeting ready",
  "Ver notas, resumen y acta ↗": "View notes, summary and minutes ↗",
  "Copiar": "Copy",
  "Nueva grabación": "New recording",
  "Servidor": "Server",
  "Guardar": "Save",
  "Nivel de sonido": "Sound level"
};

// Traduce los textos fijos del HTML (texto, placeholder, aria-label y title)
function translateStatic() {
  document.documentElement.lang = UI_LANG;
  if (UI_LANG !== "en") return;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    const key = node.nodeValue.replace(/\s+/g, " ").trim();
    if (key && STATIC_EN[key]) node.nodeValue = node.nodeValue.replace(key, STATIC_EN[key]);
  }
  document.querySelectorAll("[placeholder],[aria-label],[title]").forEach((el) => {
    ["placeholder", "aria-label", "title"].forEach((a) => {
      const v = el.getAttribute(a);
      if (v && STATIC_EN[v.trim()]) el.setAttribute(a, STATIC_EN[v.trim()]);
    });
  });
  if (STATIC_EN[document.title]) document.title = STATIC_EN[document.title];
}
translateStatic();

(function () {
  const BLOCK_SEC = 180;
  const BITRATE = 48000;
  const MAX_RETRIES = 3;
  const CLOUD_URL = "https://apex-vox.ialabs.app";
  // The Chrome Web Store package has no localhost permission: it only talks to the official server.
  const LOCKED_TO_CLOUD = !(chrome.runtime.getManifest().host_permissions || []).some((h) =>
    /localhost|127\.0\.0\.1/.test(h)
  );
  const SOUND_RMS = 0.006; // ~ -44 dBFS: por encima se considera que hay sonido
  const SILENCE_WARN_SEC = 15; // aviso tras este silencio continuo
  const WAVE_POINTS = 160;

  const $ = (id) => document.getElementById(id);
  const el = {
    form: $("setup-form"),
    meetingType: $("meeting-type"),
    title: $("title"),
    engine: $("engine"),
    modeHint: $("mode-hint"),
    pill: $("rec-pill"),
    clock: $("clock"),
    recBtn: $("rec-btn"),
    loginBtn: $("login-btn"),
    account: $("account"),
    blocks: $("stat-blocks"),
    segments: $("stat-segments"),
    speakers: $("stat-speakers"),
    pending: $("stat-pending"),
    status: $("status"),
    wave: $("wave"),
    signal: $("signal"),
    sources: $("sources"),
    result: $("result"),
    resultMeta: $("result-meta"),
    resultLink: $("result-link"),
    resultUrl: $("result-url"),
    copyBtn: $("copy-btn"),
    newBtn: $("new-btn"),
    serverUrl: $("server-url"),
    saveServer: $("save-server"),
  };

  const st = {
    serverUrl: CLOUD_URL,
    source: null, // { id, url, title } pestaña de la reunión virtual
    recording: false,
    busy: false,
    boxSessionId: null,
    startedAt: 0,
    blockIndex: 0,
    recorder: null,
    rotationTimer: null,
    tickTimer: null,
    streams: [],
    audioCtx: null,
    inFlight: new Set(),
    retryQueue: [],
    blocksSent: 0,
    failedBlocks: 0,
    segments: 0,
    speakers: new Set(),
    meters: [], // [{ label, level, lastSoundAt, ended, row }]
    wave: [],
    lastTickAt: 0,
    token: null,
    user: null,
  };

  // ---------------------------------------------------------------------------
  // Utilidades
  // ---------------------------------------------------------------------------

  function hhmmss(sec) {
    const s = Math.max(0, Math.floor(sec));
    return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60]
      .map((v) => String(v).padStart(2, "0"))
      .join(":");
  }

  // El badge admite ~4 caracteres: 9:59 → 59m → 1h05 → 10h
  function badgeTime(sec) {
    const s = Math.floor(sec);
    if (s < 600) return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
    if (s < 3600) return `${Math.floor(s / 60)}m`;
    const h = Math.floor(s / 3600);
    return h >= 10 ? `${h}h` : `${h}h${String(Math.floor((s % 3600) / 60)).padStart(2, "0")}`;
  }

  function elapsedSec() {
    return st.startedAt ? (Date.now() - st.startedAt) / 1000 : 0;
  }

  function mode() {
    return el.form.querySelector('input[name="mode"]:checked').value;
  }

  function setMode(value) {
    const input = el.form.querySelector(`input[name="mode"][value="${value}"]`);
    if (input) input.checked = true;
    renderModeHint();
  }

  // Solo orígenes http(s) válidos: el valor guardado no puede inyectar HTML ni otro esquema (javascript:).
  function safeServerUrl(value) {
    try {
      const u = new URL(String(value || "").trim());
      const local = ["localhost", "127.0.0.1", "[::1]"].includes(u.hostname);
      if (u.protocol === "https:" || (u.protocol === "http:" && local)) return u.origin;
    } catch (err) {
      /* valor inválido: se usa el servidor oficial */
    }
    return CLOUD_URL;
  }

  function detectPlatform(url) {
    let host = "";
    try {
      host = new URL(String(url || "")).hostname.toLowerCase();
    } catch (err) {
      return null;
    }
    const on = (domain) => host === domain || host.endsWith(`.${domain}`);
    if (on("meet.google.com")) return { id: "google_meet", label: "Google Meet" };
    if (on("zoom.us")) return { id: "zoom", label: "Zoom" };
    if (on("teams.microsoft.com") || on("teams.live.com")) return { id: "microsoft_teams", label: "Microsoft Teams" };
    if (on("webex.com")) return { id: "webex", label: "Webex" };
    return null;
  }

  function showStatus(msg, isError = false) {
    el.status.textContent = msg;
    el.status.classList.toggle("error", isError);
    el.status.classList.toggle("hidden", !msg);
  }

  async function api(path, options = {}) {
    const headers = Object.assign({}, options.headers || {});
    if (st.token) headers.Authorization = `Bearer ${st.token}`;
    const res = await fetch(`${st.serverUrl}${path}`, Object.assign({}, options, { headers }));
    let data = {};
    try {
      data = await res.json();
    } catch (_) {
      data = {};
    }
    if (res.status === 401) {
      st.token = null;
      st.user = null;
      renderAccount();
      throw new Error(L("Tu sesión expiró. Inicia sesión en Apex Vox y vuelve a intentarlo.", "Your session expired. Sign in to Apex Vox and try again."));
    }
    if (!res.ok) throw new Error(data.detail || L(`El servidor respondió HTTP ${res.status}`, `Server answered HTTP ${res.status}`));
    return data;
  }

  // ---------------------------------------------------------------------------
  // Sesión: el token llega desde la web de Apex Vox (content/session-bridge.js)
  // ---------------------------------------------------------------------------

  async function loadSession() {
    const { authToken, authOrigin } = await chrome.storage.local.get(["authToken", "authOrigin"]);
    st.token = authToken && authOrigin === new URL(st.serverUrl).origin ? authToken : null;
    st.user = null;
    if (st.token) {
      try {
        st.user = await api("/api/auth/me");
      } catch (_) {
        st.user = null;
      }
    }
    renderAccount();
  }

  function renderAccount() {
    const signedIn = Boolean(st.token && st.user);
    if (!st.recording) {
      el.recBtn.classList.toggle("hidden", !signedIn);
      el.loginBtn.classList.toggle("hidden", signedIn);
    }
    el.account.classList.toggle("warn", !signedIn);
    if (signedIn) {
      const q = st.user.quota || {};
      const plan = q.is_unlimited
        ? "Apex Pro"
        : L(`Plan gratis · ${Math.max(0, Math.floor((q.remaining_today_seconds || 0) / 60))} min disponibles hoy`, `Free plan · ${Math.max(0, Math.floor((q.remaining_today_seconds || 0) / 60))} min left today`);
      el.account.textContent = `${st.user.email} · ${plan}`;
    } else {
      el.account.textContent = L("Inicia sesión en Apex Vox para grabar. Después vuelve a esta pestaña.", "Sign in to Apex Vox to record, then come back to this tab.");
    }
  }

  // ---------------------------------------------------------------------------
  // UI
  // ---------------------------------------------------------------------------

  function renderModeHint() {
    if (mode() === "presencial") {
      el.modeHint.textContent = L("Graba el micrófono de este equipo.", "Records this computer's microphone.");
      el.modeHint.classList.remove("warn");
      return;
    }
    if (st.source) {
      const p = detectPlatform(st.source.url);
      el.modeHint.textContent = L(`Graba el audio de «${(p && p.label) || st.source.title || st.source.url}» + tu micrófono.`, `Records the audio of “${(p && p.label) || st.source.title || st.source.url}” + your microphone.`);
      el.modeHint.classList.remove("warn");
    } else {
      el.modeHint.textContent =
        L("Abre la pestaña de la reunión y pulsa el icono de Apex Box para elegirla como fuente.", "Open the meeting tab and click the Apex Box icon to use it as the source.");
      el.modeHint.classList.add("warn");
    }
  }

  function renderStats() {
    el.blocks.textContent = String(st.blocksSent);
    el.segments.textContent = String(st.segments);
    el.speakers.textContent = String(st.speakers.size);
    el.pending.textContent = String(st.inFlight.size + st.retryQueue.length);
  }

  function renderRecordingState() {
    el.pill.textContent = st.recording ? "REC" : L("NO REC", "NOT REC");
    el.pill.classList.toggle("on", st.recording);
    if (!st.recording) el.pill.classList.remove("warn");
    el.recBtn.textContent = st.recording ? L("■ Detener", "■ Stop") : L("● Grabar", "● Record");
    el.recBtn.classList.toggle("stop", st.recording);
    el.recBtn.disabled = st.busy;
    el.form.querySelectorAll("input, select").forEach((n) => (n.disabled = st.recording || st.busy));
  }

  function tick() {
    st.lastTickAt = Date.now();
    const sec = elapsedSec();
    const sig = signalState();
    const noSound = sig.kind === "warn" || sig.kind === "off";
    el.clock.textContent = hhmmss(sec);
    document.title = `${noSound ? L("⚠ SIN SONIDO", "⚠ NO SOUND") : "● REC"} ${hhmmss(sec)} · Apex Box`;
    // Badge: tiempo en rojo si entra sonido; "MUDO" en ámbar si no se está captando nada.
    chrome.action.setBadgeBackgroundColor({ color: noSound ? "#d97706" : "#f43e01" });
    chrome.action.setBadgeText({ text: noSound ? L("MUDO", "MUTE") : badgeTime(sec) });
    chrome.action.setTitle({
      title: `Apex Box · REC ${hhmmss(sec)}${
        sig.kind === "off"
          ? L(" · ⚠ fuente desconectada", " · ⚠ source disconnected")
          : noSound
          ? L(` · ⚠ sin sonido hace ${sig.silentSec} s`, ` · ⚠ no sound for ${sig.silentSec} s`)
          : L(" · captando sonido", " · picking up sound")
      }`,
    });
    if (document.hidden) return;
    renderMeters();
  }

  function setIdleIndicator() {
    document.title = L("Apex Box · Grabador", "Apex Box · Recorder");
    chrome.action.setBadgeText({ text: "" });
    chrome.action.setTitle({ title: L("Apex Box · No grabando", "Apex Box · Not recording") });
  }

  // ---------------------------------------------------------------------------
  // Captura de audio
  // ---------------------------------------------------------------------------

  async function getMic() {
    const mic = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false,
    });
    st.streams.push(mic);
    return mic;
  }

  async function acquireStream() {
    st.meterSources = [];
    if (mode() === "presencial") {
      const mic = await getMic();
      st.meterSources.push({ label: L("Micrófono", "Microphone"), stream: mic, node: st.audioCtx.createMediaStreamSource(mic) });
      return mic;
    }

    if (!st.source) {
      throw new Error(L("Elige la pestaña de la reunión: ábrela y pulsa el icono de Apex Box.", "Choose the meeting tab: open it and click the Apex Box icon."));
    }
    const me = await chrome.tabs.getCurrent();
    const streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: st.source.id,
      consumerTabId: me.id,
    });
    const tabStream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } },
      video: false,
    });
    st.streams.push(tabStream);

    const out = st.audioCtx.createMediaStreamDestination();
    const tabSrc = st.audioCtx.createMediaStreamSource(tabStream);
    tabSrc.connect(st.audioCtx.destination); // seguir escuchando la reunión
    tabSrc.connect(out);
    st.meterSources.push({ label: L("Reunión", "Meeting"), stream: tabStream, node: tabSrc });

    try {
      const mic = await getMic();
      const micSrc = st.audioCtx.createMediaStreamSource(mic);
      micSrc.connect(out);
      st.meterSources.push({ label: L("Micrófono", "Microphone"), stream: mic, node: micSrc });
    } catch (_) {
      showStatus(L("Grabando solo el audio de la reunión (sin micrófono).", "Recording only the meeting audio (no microphone)."));
    }
    return out.stream;
  }

  // ---------------------------------------------------------------------------
  // Medidor de sonido: ondas + aviso de silencio
  // ---------------------------------------------------------------------------

  // dBFS -60..0 → 0..1
  function levelToUnit(rms) {
    if (rms <= 0) return 0;
    return Math.min(1, Math.max(0, (20 * Math.log10(rms) + 60) / 60));
  }

  async function startMeters() {
    const ctx = st.audioCtx;
    await ctx.audioWorklet.addModule("level-meter.js");
    // Salida a ganancia 0 → destino: asegura que el grafo procese el medidor sin sonar.
    const sink = ctx.createGain();
    sink.gain.value = 0;
    sink.connect(ctx.destination);

    const now = Date.now();
    el.sources.textContent = "";
    st.meters = st.meterSources.map(({ label, stream, node }) => {
      const row = document.createElement("li");
      const labelSpan = document.createElement("span");
      labelSpan.textContent = label;
      const barSpan = document.createElement("span");
      barSpan.className = "bar";
      const barFill = document.createElement("i");
      barSpan.appendChild(barFill);
      const stateSpan = document.createElement("span");
      stateSpan.className = "state";
      row.appendChild(labelSpan);
      row.appendChild(barSpan);
      row.appendChild(stateSpan);
      el.sources.appendChild(row);

      const meter = { label, level: 0, lastSoundAt: now, ended: false, row };
      const worklet = new AudioWorkletNode(ctx, "level-meter");
      worklet.port.onmessage = (e) => onLevel(meter, e.data);
      node.connect(worklet);
      worklet.connect(sink);

      stream.getAudioTracks().forEach((t) => {
        t.addEventListener("ended", () => (meter.ended = true));
      });
      return meter;
    });
    st.wave = [];
  }

  function onLevel(meter, { rms }) {
    const now = Date.now();
    meter.level = rms;
    if (rms >= SOUND_RMS) meter.lastSoundAt = now;

    // El primer medidor marca el ritmo de la onda (≈20 puntos/s) con el nivel combinado.
    if (meter === st.meters[0]) {
      const combined = Math.max(...st.meters.map((m) => m.level));
      st.wave.push(combined);
      if (st.wave.length > WAVE_POINTS) st.wave.shift();
      if (!document.hidden) renderMeters();
      // Los mensajes del hilo de audio no se frenan en segundo plano: también mueven el reloj/badge.
      if (st.recording && now - st.lastTickAt >= 1000) tick();
    }
  }

  function signalState() {
    if (!st.recording || !st.meters.length) return { kind: "idle", silentSec: 0 };
    const now = Date.now();
    if (st.meters.every((m) => m.ended)) return { kind: "off", silentSec: 0 };
    const lastSound = Math.max(...st.meters.filter((m) => !m.ended).map((m) => m.lastSoundAt));
    const silentSec = Math.floor((now - lastSound) / 1000);
    return { kind: silentSec >= SILENCE_WARN_SEC ? "warn" : "ok", silentSec };
  }

  function renderMeters() {
    const sig = signalState();
    el.signal.className = `signal ${sig.kind}`;
    el.signal.textContent = {
      idle: L("Sin grabar", "Not recording"),
      ok: L("● Captando sonido", "● Picking up sound"),
      warn: L(`⚠ No entra sonido hace ${sig.silentSec} s — revisa micrófono o pestaña`, `⚠ No sound for ${sig.silentSec} s — check the microphone or tab`),
      off: L("⚠ Fuente de audio desconectada — no se está grabando sonido", "⚠ Audio source disconnected — no sound is being recorded"),
    }[sig.kind];

    if (st.recording) {
      const noSound = sig.kind === "warn" || sig.kind === "off";
      el.pill.textContent = noSound ? L("REC · SIN SONIDO", "REC · NO SOUND") : "REC";
      el.pill.classList.toggle("warn", noSound);
    }

    const now = Date.now();
    st.meters.forEach((m) => {
      const silent = (now - m.lastSoundAt) / 1000 >= SILENCE_WARN_SEC;
      m.row.className = m.ended ? "off" : silent ? "warn" : "";
      m.row.querySelector("i").style.width = `${Math.round(levelToUnit(m.level) * 100)}%`;
      m.row.querySelector(".state").textContent = m.ended ? L("desconectada", "disconnected") : silent ? L("sin señal", "no signal") : "ok";
    });

    drawWave(sig.kind);
  }

  function drawWave(kind) {
    const c = el.wave;
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(c.clientWidth * dpr));
    const h = Math.max(1, Math.round(c.clientHeight * dpr));
    if (c.width !== w || c.height !== h) {
      c.width = w;
      c.height = h;
    }
    const g = c.getContext("2d");
    g.clearRect(0, 0, w, h);
    const mid = h / 2;
    g.fillStyle = { ok: "#225c05", warn: "#d97706", off: "#c93706" }[kind] || "#cecebf";

    const step = w / WAVE_POINTS;
    const barW = Math.max(1, step * 0.6);
    const offset = WAVE_POINTS - st.wave.length;
    for (let i = 0; i < WAVE_POINTS; i++) {
      const v = i >= offset ? levelToUnit(st.wave[i - offset]) : 0;
      const bh = Math.max(dpr, v * (h - 4 * dpr));
      g.fillRect(i * step, mid - bh / 2, barW, bh);
    }
  }

  function resetMeters() {
    st.meters = [];
    st.meterSources = [];
    st.wave = [];
    el.sources.textContent = "";
    renderMeters();
  }

  async function releaseStreams() {
    st.streams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    st.streams = [];
    if (st.audioCtx) {
      try {
        await st.audioCtx.close();
      } catch (_) {}
      st.audioCtx = null;
    }
  }

  function mimeType() {
    return ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"].find((m) =>
      MediaRecorder.isTypeSupported(m)
    );
  }

  // ---------------------------------------------------------------------------
  // Bloques: subir y liberar RAM
  // ---------------------------------------------------------------------------

  async function uploadBlock(item) {
    const ext = item.blob.type.includes("mp4") ? "m4a" : item.blob.type.includes("ogg") ? "ogg" : "webm";
    const fd = new FormData();
    fd.append("file", item.blob, `bloque_${String(item.index + 1).padStart(4, "0")}.${ext}`);
    fd.append("block_index", String(item.index));
    fd.append("duration_hint_sec", String(item.durationSec));
    fd.append("transcribe_immediately", "true");

    const data = await api(`/api/box/sessions/${encodeURIComponent(item.sessionId)}/blocks`, {
      method: "POST",
      body: fd,
    });
    st.blocksSent = data.total_blocks_received || st.blocksSent + 1;
    st.segments = data.total_segments_count || st.segments;
    (data.new_segments || []).forEach((s) => s.speaker && st.speakers.add(s.speaker));
  }

  function sendBlock(item) {
    let p;
    p = (async () => {
      try {
        await uploadBlock(item);
      } catch (_) {
        item.attempts = (item.attempts || 0) + 1;
        if (item.attempts < MAX_RETRIES) st.retryQueue.push(item);
        else st.failedBlocks += 1;
      } finally {
        st.inFlight.delete(p);
        renderStats();
      }
    })();
    st.inFlight.add(p);
    renderStats();
    return p;
  }

  function retryFailed() {
    const items = st.retryQueue.splice(0);
    return Promise.all(items.map(sendBlock));
  }

  function startBlock(stream) {
    const type = mimeType();
    const rec = new MediaRecorder(stream, { audioBitsPerSecond: BITRATE, ...(type ? { mimeType: type } : {}) });
    const index = st.blockIndex++;
    const sessionId = st.boxSessionId;
    const startedAt = Date.now();
    let chunks = [];

    rec.ondataavailable = (e) => e.data && e.data.size > 0 && chunks.push(e.data);
    rec.stopped = new Promise((resolve) => {
      rec.onstop = () => {
        const blob = new Blob(chunks, { type: rec.mimeType || type || "audio/webm" });
        chunks = null; // liberar RAM del bloque
        const durationSec = Number(Math.max(0.5, (Date.now() - startedAt) / 1000).toFixed(2));
        if (blob.size > 0) sendBlock({ blob, index, durationSec, sessionId });
        retryFailed();
        resolve();
      };
    });
    rec.start();
    return rec;
  }

  // ---------------------------------------------------------------------------
  // Grabar / Detener (con bloqueo de estado en chrome.storage.session)
  // ---------------------------------------------------------------------------

  async function startRecording() {
    const { recordingState = "idle" } = await chrome.storage.session.get("recordingState");
    if (recordingState === "starting" || recordingState === "stopping" || st.busy) return;

    if (!st.token || !st.user) {
      renderAccount();
      showStatus(L("Inicia sesión en Apex Vox para grabar.", "Sign in to Apex Vox to record."), true);
      return;
    }

    await chrome.storage.session.set({ recordingState: "starting" });
    // Crear el AudioContext en el mismo clic evita que Chrome lo deje suspendido
    st.audioCtx = new AudioContext();
    st.busy = true;
    renderRecordingState();
    el.result.classList.add("hidden");
    showStatus(L("Preparando grabación…", "Preparing recording…"));

    try {
      const stream = await acquireStream();
      if (st.audioCtx.state === "suspended") {
        try {
          await st.audioCtx.resume();
        } catch (_) {}
      }
      await startMeters();
      const platform = mode() === "virtual" && st.source ? detectPlatform(st.source.url) : null;
      const session = await api("/api/box/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: el.title.value.trim() || L("Reunión — Apex Box", "Meeting — Apex Box"),
          mode: mode(),
          platform: mode() === "virtual" ? (platform && platform.id) || "google_meet" : "in_person",
          meeting_url: mode() === "virtual" && st.source ? st.source.url : null,
          block_duration_sec: BLOCK_SEC,
          language: "es",
          diarization_engine: el.engine.value,
          device_type: "desktop_extension",
        }),
      });

      Object.assign(st, {
        boxSessionId: session.box_session_id,
        blockIndex: 0,
        blocksSent: 0,
        failedBlocks: 0,
        segments: 0,
        speakers: new Set(),
        retryQueue: [],
        startedAt: Date.now(),
        recording: true,
      });

      await chrome.storage.session.set({ recordingState: "recording" });
      st.recorder = startBlock(stream);
      // Rotación sin cortes: arranca el siguiente bloque antes de cerrar el anterior.
      st.rotationTimer = setInterval(() => {
        const prev = st.recorder;
        st.recorder = startBlock(stream);
        if (prev.state !== "inactive") prev.stop();
      }, BLOCK_SEC * 1000);

      tick();
      st.tickTimer = setInterval(tick, 1000);
      showStatus("");
      await chrome.storage.local.set({
        lastMeetingType: el.meetingType.value,
        lastMode: mode(),
        lastEngine: el.engine.value,
      });
    } catch (err) {
      await chrome.storage.session.set({ recordingState: "idle" });
      await releaseStreams();
      resetMeters();
      showStatus(L(`No se pudo iniciar: ${err.message}`, `Could not start: ${err.message}`), true);
    } finally {
      st.busy = false;
      renderStats();
      renderRecordingState();
    }
  }

  async function stopRecording() {
    const { recordingState = "idle" } = await chrome.storage.session.get("recordingState");
    if (recordingState === "starting" || recordingState === "stopping") return;

    await chrome.storage.session.set({ recordingState: "stopping" });
    st.busy = true;
    renderRecordingState();
    clearInterval(st.rotationTimer);
    clearInterval(st.tickTimer);
    const totalSec = elapsedSec();
    showStatus(L("Subiendo el último bloque…", "Uploading the last block…"));

    try {
      if (st.recorder && st.recorder.state !== "inactive") {
        st.recorder.stop();
        await st.recorder.stopped;
      }
      await releaseStreams();
      // Esperar subidas en curso y reintentar las fallidas.
      while (st.inFlight.size || st.retryQueue.length) {
        await Promise.all([...st.inFlight]);
        if (st.retryQueue.length) await new Promise((r) => setTimeout(r, 2000));
        await retryFailed();
      }

      showStatus(L("Generando notas, resumen y acta…", "Creating notes, summary and minutes…"));
      const fin = await api(`/api/box/sessions/${encodeURIComponent(st.boxSessionId)}/finalize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ generate_minutes: true, generate_minutes_template: el.meetingType.value }),
      });

      const url = new URL(`/?job=${encodeURIComponent(fin.job_id)}`, safeServerUrl(st.serverUrl)).href;
      el.resultLink.href = url;
      el.resultUrl.value = url;
      el.resultMeta.textContent = `${fin.total_duration_formatted || hhmmss(totalSec)} · ${
        fin.total_blocks || st.blocksSent
      } ${L("bloques", "blocks")} · ${fin.notes_integrated_count || 0} ${L("notas", "notes")}${
        st.failedBlocks ? L(` · ⚠ ${st.failedBlocks} bloque(s) no se pudieron subir`, ` · ⚠ ${st.failedBlocks} block(s) could not be uploaded`) : ""
      }`;
      el.result.classList.remove("hidden");
      showStatus("");
    } catch (err) {
      showStatus(L(`Error al finalizar: ${err.message}`, `Could not finish: ${err.message}`), true);
    } finally {
      await chrome.storage.session.set({ recordingState: "idle" });
      st.recording = false;
      st.busy = false;
      st.recorder = null;
      resetMeters();
      setIdleIndicator();
      await loadSession();
      renderStats();
      renderRecordingState();
    }
  }

  // ---------------------------------------------------------------------------
  // Eventos
  // ---------------------------------------------------------------------------

  el.recBtn.addEventListener("click", () => (st.recording ? stopRecording() : startRecording()));
  el.loginBtn.addEventListener("click", () => chrome.tabs.create({ url: `${st.serverUrl}/?view=portal&login=1` }));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.authToken || changes.authOrigin) && !st.recording) loadSession();
  });
  el.form.addEventListener("change", renderModeHint);
  el.form.addEventListener("submit", (e) => e.preventDefault());

  el.copyBtn.addEventListener("click", async () => {
    await navigator.clipboard.writeText(el.resultUrl.value);
    el.copyBtn.textContent = L("Copiado", "Copied");
    setTimeout(() => (el.copyBtn.textContent = L("Copiar", "Copy")), 1500);
  });

  el.newBtn.addEventListener("click", () => {
    el.result.classList.add("hidden");
    el.clock.textContent = "00:00:00";
    Object.assign(st, { blocksSent: 0, segments: 0, speakers: new Set(), startedAt: 0 });
    renderStats();
  });

  if (el.saveServer && el.serverUrl) {
    el.saveServer.addEventListener("click", async () => {
      st.serverUrl = safeServerUrl(el.serverUrl.value || CLOUD_URL);
      el.serverUrl.value = st.serverUrl;
      await chrome.storage.local.set({ serverUrl: st.serverUrl });
      showStatus(L(`Servidor: ${st.serverUrl}`, `Server: ${st.serverUrl}`));
      await loadSession();
    });
  }

  window.addEventListener("beforeunload", (e) => {
    if (st.recording) {
      e.preventDefault();
      e.returnValue = "";
    }
  });

  function setSource(tab) {
    if (st.recording || !tab) return;
    st.source = { id: tab.id, url: tab.url || "", title: tab.title || "" };
    const p = detectPlatform(st.source.url);
    if (p) {
      setMode("virtual");
      if (!el.title.value.trim()) el.title.value = `${p.label}: ${st.source.title}`.slice(0, 140);
    }
    renderModeHint();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "SOURCE_TAB") setSource({ id: msg.tabId, url: msg.url, title: msg.title });
  });

  // ---------------------------------------------------------------------------
  // Arranque
  // ---------------------------------------------------------------------------

  (async () => {
    const saved = await chrome.storage.local.get(["serverUrl", "lastMeetingType", "lastMode", "lastEngine"]);
    if (LOCKED_TO_CLOUD) {
      st.serverUrl = CLOUD_URL;
      $("server-settings").classList.add("hidden");
      const locked = $("server-locked");
      locked.textContent = L("Conectado a apex-vox.ialabs.app", "Connected to apex-vox.ialabs.app");
      locked.classList.remove("hidden");
    } else if (saved.serverUrl && el.serverUrl) {
      st.serverUrl = el.serverUrl.value = safeServerUrl(saved.serverUrl);
    } else {
      st.serverUrl = CLOUD_URL;
    }
    if (saved.lastMeetingType) el.meetingType.value = saved.lastMeetingType;
    if (saved.lastEngine) el.engine.value = saved.lastEngine;
    if (saved.lastMode) setMode(saved.lastMode);

    const sourceId = Number(new URLSearchParams(location.search).get("source"));
    if (sourceId) {
      try {
        setSource(await chrome.tabs.get(sourceId));
      } catch (_) {}
    }
    setIdleIndicator();
    renderModeHint();
    renderStats();
    renderRecordingState();
    renderMeters();
    await loadSession();
  })();

  document.addEventListener("visibilitychange", () => !document.hidden && renderMeters());
  window.addEventListener("resize", renderMeters);
})();
